package by.tms.bookstorec37.service;

import by.tms.bookstorec37.entity.Basket;
import by.tms.bookstorec37.entity.Book;
import by.tms.bookstorec37.repository.BasketRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class BasketService {

    @Autowired
    public BasketRepository basketRepository;

    List<Book> tempBookList = new ArrayList<>();

    public static List<Basket> basketList = new ArrayList<>();

    public void addBookList (List<Book> bookList) {
        Basket newBasket = new Basket();
        newBasket.setBookList(bookList);
        tempBookList = bookList;
        basketRepository.save(newBasket);
    }

    public List<Book> getBookList () {
        return tempBookList;
    }

    public void addNewBasket (Basket basket) {
        basketList.add(basket);
        basketRepository.save(basket);
    }

    public Basket getBasket (Basket basket) {
        for (Basket getBasket: basketList
             ) {
            if (getBasket.equals(basket)) {
                return getBasket;
            }
        } return null;
    }

    public Basket getBasketByUserId (long userId) {
        return basketRepository.findByUserId(userId);
    }

    public void addBookToBasket (Book book, long userId) {
        basketRepository.findByUserId(userId).getBookList().add(book);
    }
}