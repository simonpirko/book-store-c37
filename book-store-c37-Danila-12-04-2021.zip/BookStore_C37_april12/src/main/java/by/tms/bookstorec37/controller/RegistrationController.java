package by.tms.bookstorec37.controller;

import by.tms.bookstorec37.entity.security.User;
import by.tms.bookstorec37.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/user")
public class RegistrationController {

    @Autowired
    private UserService userService;

    @GetMapping(path = "/reg")
    public ModelAndView getRegPage(ModelAndView modelAndView){
        modelAndView.setViewName("/user/reg");
        modelAndView.addObject("ModelAttribute", new User());
        return modelAndView;
    }

    @PostMapping(path = "/reg")
    public ModelAndView postRegPage(@ModelAttribute("ModelAttribute")User user, ModelAndView modelAndView){
        if (userService.isUserExistByUserName(user.getUsername())){
            modelAndView.addObject("userIsExistsError", "User with this username is already exists!");
            modelAndView.setViewName("/user/reg");
            return modelAndView;
        }
        userService.addUser(user);
        modelAndView.setViewName("redirect:/user/auth");
        return modelAndView;
    }

    @GetMapping(path = "/auth")
    public ModelAndView getLoginPage(@RequestParam(value = "error", required = false) String error,
                                     @RequestParam(value = "logout", required = false) String logout,
                                     ModelAndView modelAndView) {
        modelAndView.addObject("error", error != null);
        modelAndView.addObject("logout", logout != null);
        modelAndView.setViewName("/user/auth");
        return modelAndView;
    }

//    @PostMapping(path = "/auth")
//    public ModelAndView postAuthPage(@ModelAttribute("ModelAttribute")User user, ModelAndView modelAndView){
//        modelAndView.setViewName("/user/auth");
//        if(userService.isUserExistByUserName(user.getUsername())) {
//            if (userService.isPasswordCorrect(user.getUsername(), user.getPassword())) {
//                modelAndView.addObject("userAuthOk", "User Authorization Ok");
//                modelAndView.setViewName("redirect:/user/auth");
//            } else {
//                modelAndView.addObject("Password incorrect", "Password incorrect");
//            }
//        } else {
//            modelAndView.addObject("Name incorrect", "Name incorrect");
//        }
//        return modelAndView;
//    }
}