package by.tms.bookstorec37.controller;

import by.tms.bookstorec37.entity.*;
import by.tms.bookstorec37.service.BasketService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping({"/book", "/order"})
public class BookTicketController {

    @Autowired
    TempBookList tempBookList;

    @Autowired
    BasketService basketService;

    @Autowired
    TempBasketList tempBasketList;

    @GetMapping(path = "/bookTicket/{id}")
    public ModelAndView showBookTicket (@PathVariable Long id,
                                        @ModelAttribute("bookForBasket") BookForBasket bookForBasket,
                                        ModelAndView modelAndView) {
        Book openedBook = new Book();
        List<Book> list = tempBookList.getList();
        for (Book book : list
             ) {
            if (book.getId() == id) {
                openedBook = book;
            }
        }
        modelAndView.addObject("openedBook", openedBook);
        modelAndView.setViewName("/book/bookTicket");
        return modelAndView;
    }

    @PostMapping(path = "/bookTicket")
    public ModelAndView putBookToBasket (@ModelAttribute("bookForBasket") BookForBasket bookForBasket,
                                         ModelAndView modelAndView) {
        modelAndView.setViewName("redirect:/order/basketGet");
//        basketService.addBookToBasket(bookForBasket.getBook(), bookForBasket.getUserId());
        Basket currentBasket = new Basket();
        List<Book> currentBookList = new ArrayList<>();
        currentBasket.setBookList(currentBookList);
        currentBasket.getBookList().add(bookForBasket.getBook());
        currentBasket.setUserId(bookForBasket.getUserId());
        tempBasketList.addBasketToBasketList(currentBasket);
        tempBasketList.getBasketByUserId(bookForBasket.getUserId());
//        modelAndView.addObject("currentUserBasket", basketService.getBasketByUserId(bookForBasket.getUserId()));
//        modelAndView.addObject("currentUserBasket", currentBasket);
        return modelAndView;
    }
}