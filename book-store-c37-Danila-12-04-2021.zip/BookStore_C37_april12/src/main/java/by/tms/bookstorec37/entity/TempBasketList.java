package by.tms.bookstorec37.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Data
@Component
@AllArgsConstructor
//@NoArgsConstructor
public class TempBasketList {

    private static List<Basket> tempBasketList = new ArrayList<>();

    public void addBasketToBasketList (Basket basket) {
//        tempBasketList.removeAll(tempBasketList);
        tempBasketList.add(basket);
    }

    public Basket getBasketByUserId (long userId) {
        for (Basket basket : tempBasketList) {
            if (basket.getUserId() == userId) {
                Basket b = basket;
                tempBasketList.remove(basket);
                return b;
            }
        }
        return null;
    }

}
