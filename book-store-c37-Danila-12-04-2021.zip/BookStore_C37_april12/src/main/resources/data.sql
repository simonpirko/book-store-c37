
insert into users (username, password) values ('admin', '$2y$10$o5l8bpRYWn79jxiY0o944e2crMyu3rlvHrZ.xfjki1UkFCWkLqWui');

insert into user_role (user_id, roles) values (1, 'ROLE_ADMIN');
insert into user_role (user_id, roles) values (1, 'ROLE_USER')
