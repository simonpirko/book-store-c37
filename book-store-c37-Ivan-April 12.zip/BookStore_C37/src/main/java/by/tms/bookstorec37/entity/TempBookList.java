package by.tms.bookstorec37.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Data
@Component
public class TempBookList {

    private static List<Book> testBookList = new ArrayList<>();

    {
        Book book1 = new Book(1, "Витки", "Fantastic", new Author(1, "Clifford Donald", "Simak"), 25);
        Book book2 = new Book(2, "Шерлок Холмс", "Adventure", new Author(2, "Arthur", "Conan Doyle"), 30);
        Book book3 = new Book(3, "Гамлет", "Drama", new Author(3, "William", "Shakespeare"), 15);
        testBookList.add(book1);
        testBookList.add(book2);
        testBookList.add(book3);
    }

    public List<Book> getList () {
        return new ArrayList<>(testBookList);
    }
}
