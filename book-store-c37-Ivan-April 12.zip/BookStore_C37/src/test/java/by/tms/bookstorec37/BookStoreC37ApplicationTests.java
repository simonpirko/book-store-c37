package by.tms.bookstorec37;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookStoreC37ApplicationTests {

	@Test
	void contextLoads() {
	}

}
