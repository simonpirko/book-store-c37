package by.tms.bookstorec37.service;

import by.tms.bookstorec37.entity.Basket;
import by.tms.bookstorec37.entity.Book;
import by.tms.bookstorec37.repository.BasketRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class BasketService {

    @Autowired
    public BasketRepository basketRepository;

    List<Book> tempBookList = new ArrayList<>();

    public void addBookList (List<Book> bookList) {
        Basket newBasket = new Basket();
        newBasket.setBookList(bookList);
        tempBookList = bookList;
        basketRepository.save(newBasket);
    }

    public List<Book> getBookList () {
        return tempBookList;
    }


}