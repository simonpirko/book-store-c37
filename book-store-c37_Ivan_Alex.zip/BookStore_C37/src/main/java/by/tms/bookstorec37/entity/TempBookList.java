package by.tms.bookstorec37.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Data
@Component
public class TempBookList {

    private static List<Book> testBookList = new ArrayList<>();

    {
        Book book1 = new Book(1, "test1");
        Book book2 = new Book(2, "test2");
        Book book3 = new Book(3, "test3");
        testBookList.add(book1);
        testBookList.add(book2);
        testBookList.add(book3);
    }

    public List<Book> getList () {
        return new ArrayList<>(testBookList);
    }
}
