package by.tms.bookstorec37.controller;

import by.tms.bookstorec37.entity.*;
import by.tms.bookstorec37.service.BasketService;
import by.tms.bookstorec37.service.OrderService;
import by.tms.bookstorec37.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.Date;
import java.util.List;
import java.util.Set;

@Controller
@RequestMapping(path = "/order")
public class BasketController {

    @Autowired
    BasketService basketService;

    @Autowired
    OrderService orderService;

    @Autowired
    UserService userService;

    @Autowired
    TempBasketList tempBasketList;

    @GetMapping(path = "/basketGet")
    public ModelAndView showBasket (
                                    ModelAndView modelAndView) {
//        modelAndView.addObject("currentUserBasket", tempBasketList.getBasketByUserId(1));
        modelAndView.addObject("basketList", tempBasketList.getBasketByUserId(1).getBookList());
        modelAndView.setViewName("/order/basket");
        return modelAndView;
    }

//    @PostMapping(path = "/basketPost")
//    public ModelAndView createNewOrder (@ModelAttribute("BasketModel")Basket basket,
//                                       ModelAndView modelAndView) {
//        modelAndView.setViewName("/order/basket");
////        Order newOrder = new Order();
////        newOrder.setBookList(basket.getBookList());
////        newOrder.setOrderStatus(OrderStatus.NEW);
////        newOrder.setUser(userService.getUserById(basket.getUserId()));
////        newOrder.setOrderCreationDate(new Date().toString());
////        modelAndView.addObject("newOrder", newOrder);
//////      orderService.addNewOrder(newOrder);
//
////        basketService.addBookList(basket.getBookList());
////        modelAndView.addObject("newBasket", newBasket);
//        return modelAndView;
//    }
}
