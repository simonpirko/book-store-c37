package by.tms.bookstorec37.controller;

import by.tms.bookstorec37.entity.*;
import by.tms.bookstorec37.service.BasketService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping({"/book", "/order"})
public class BookTicketController {

    @Autowired
    TempBookList tempBookList;

    @Autowired
    BasketService basketService;

    @Autowired
    TempBasketList tempBasketList;

    Book openedBook = new Book();

    Basket newBasket = new Basket();

    private Basket newBasket() {
        User currentUser = new User(1, "test","test");
        if (!tempBasketList.basketExistByUserId(currentUser.getId())) {
            newBasket.setUserId(currentUser.getId());
            List<Book> bookListInBasket = new ArrayList<>();
            newBasket.setBookList(bookListInBasket);
            tempBasketList.addBasketToBasketList(newBasket);
            return newBasket;
        } else {
            return null;
        }
    }


    @GetMapping(path = "/bookTicket/{id}")
    public ModelAndView showBookTicket (@PathVariable Long id,
                                        @ModelAttribute("bookForBasket") BookForBasket bookForBasket,
                                        ModelAndView modelAndView) {
        List<Book> list = tempBookList.getList();
        for (Book book : list
             ) {
            if (book.getId() == id) {
                openedBook = book;
            }
        }
        modelAndView.addObject("newBasket", newBasket);
        modelAndView.addObject("openedBook", openedBook);
        modelAndView.setViewName("/book/bookTicket");
        newBasket();
//        User currentUser = new User(1, "test","test");
//        if (!tempBasketList.basketExistByUserId(currentUser.getId())) {
//            Basket newBasket = new Basket();
//            newBasket.setUserId(currentUser.getId());
//            List<Book> bookListInBasket = new ArrayList<>();
//            newBasket.setBookList(bookListInBasket);
//            tempBasketList.addBasketToBasketList(newBasket);
//            bookListInBasket.add(openedBook);
        return modelAndView;
    }
//    ,
    @PostMapping(path = "/bookTicket/{id}")
        public ModelAndView putBookToBasket (@PathVariable Long id,
        ModelAndView modelAndView) {
        List<Book> list = tempBookList.getList();
        for (Book book : list
        ) {
            if (book.getId() == id) {
                openedBook = book;
            }
        }
//        basketService.addBookToBasket(bookForBasket.getBook(), bookForBasket.getUserId());
//            tempBasketList.getBasketByUserId(1).getBookList().add(bookForBasket.getBook());
        modelAndView.setViewName("/book/bookTicket");
        newBasket.getBookList().add(openedBook);
        modelAndView.addObject("openedBook", openedBook);
        modelAndView.addObject("newBasket", newBasket);
        modelAndView.addObject("addedBookToBasketMessage", "book " + openedBook.getName() + " added");
        return modelAndView;
    }
}