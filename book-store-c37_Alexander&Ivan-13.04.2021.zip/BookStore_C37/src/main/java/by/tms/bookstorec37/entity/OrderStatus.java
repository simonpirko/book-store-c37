package by.tms.bookstorec37.entity;

public  enum OrderStatus {
    NEW, PROCESSED, DELIVERED
}
