package by.tms.bookstorec37.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table

public class Basket {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private long userId;
    @OneToMany (cascade = CascadeType.ALL)
    private Set<Book> bookList;


    public Basket(Set<Book> bookList) {
        this.bookList = bookList;
    }

    public Set<Book> getBookList() {
        return bookList;
    }

//    public void setBookList(Set<Book> bookList) {
//        this.bookList = bookList;
//    }

    public Basket(long userId, Set<Book> bookList) {
        this.userId = userId;
        this.bookList = bookList;
    }

    public Basket(long userId) {
        this.userId = userId;
    }
}