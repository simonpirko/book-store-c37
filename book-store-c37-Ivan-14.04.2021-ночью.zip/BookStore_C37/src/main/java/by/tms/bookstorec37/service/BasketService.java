package by.tms.bookstorec37.service;

import by.tms.bookstorec37.entity.Basket;
import by.tms.bookstorec37.entity.Book;
import by.tms.bookstorec37.repository.BasketRepository;
import by.tms.bookstorec37.service.exception.UserNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
public class BasketService {

    @Autowired
    public BasketRepository basketRepository;

//    Set<Book> tempBookList = new HashSet<>();

//    public static List<Basket> basketList = new ArrayList<>();

//    public void addBookList (Set<Book> bookList) {
//        Basket newBasket = new Basket();
//        newBasket.setBookList(bookList);
//        tempBookList = bookList;
//        basketRepository.save(newBasket);
//    }

//    public Set<Book> getBookList () {
//        return tempBookList;
//    }

    public void addNewBasket (Basket basket) {
//        basketList.add(basket);
        basketRepository.save(basket);
    }

    public Basket getBasket (Basket basket) {
        for (Basket getBasket: basketRepository.findAll()
             ) {
            if (getBasket.equals(basket)) {
                return getBasket;
            }
        } return null;
    }

    public Basket getBasketByUserId (long userId) {
        if (!basketRepository.existsByUserId(userId)) {
            Set<Book> bookListInBasket = new HashSet<>();
            addNewBasket(new Basket(userId, bookListInBasket));
        }
        return basketRepository.findByUserId(userId);
    }

    public void addBookToBasket (Book book, long userId) {
        if (isBasketExistByUserId(userId)) {
            basketRepository.getByUserId(userId).getBookList().add(book);
        } else {
            Set<Book> bookListForBasket  = new HashSet<>();
            bookListForBasket.add(book);
            addNewBasket(new Basket(userId, bookListForBasket));
        }
    }

    public boolean isBasketExistByUserId (long userId) {
        return basketRepository.existsByUserId(userId);
    }


}