package by.tms.bookstorec37.entity;

public enum Role {
    ADMIN, USER, MANAGER, GUEST

}
