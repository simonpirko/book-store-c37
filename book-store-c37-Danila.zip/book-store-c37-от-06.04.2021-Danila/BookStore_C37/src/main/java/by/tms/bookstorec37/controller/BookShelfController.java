package by.tms.bookstorec37.controller;

import by.tms.bookstorec37.entity.Basket;
import by.tms.bookstorec37.entity.Book;
import by.tms.bookstorec37.service.BasketService;
import by.tms.bookstorec37.service.BookServise;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/order")
public class BookShelfController {

    @Autowired
    private BookServise bookServise;
    @Autowired
    private BasketService basketService;

    @GetMapping(path = "/bookShelf")
    public ModelAndView showBookShelfPage (@ModelAttribute("basketForm") Basket basket,
                                           ModelAndView modelAndView) {
        List<Book> testBookList = new ArrayList<>();
        Book book1 = new Book(1L, "test1");
        Book book2 = new Book(2L, "test2");
        Book book3 = new Book(3L, "test3");
        testBookList.add(book1);
        testBookList.add(book2);
        testBookList.add(book3);
        modelAndView.setViewName("/order/bookShelf");
        modelAndView.addObject("testBookList", testBookList);
        return modelAndView;
    }

    @PostMapping(path = "/bookShelf")
    public ModelAndView getBooksForBasket (@ModelAttribute("basketForm") Basket basket,
                                           ModelAndView modelAndView) {
        basketService.addBookList(basket.getBookList());
        modelAndView.setViewName("/order/basket");
        return modelAndView;
    }
}