package by.tms.bookstorec37.service;

import by.tms.bookstorec37.entity.Basket;
import by.tms.bookstorec37.entity.Book;
import by.tms.bookstorec37.repository.BasketRepository;
import by.tms.bookstorec37.service.exception.UserNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
public class BasketService {

    @Autowired
    public BasketRepository basketRepository;

    public void addBasket (Basket basket) {
        basketRepository.save(basket);
    }

    public void createNewEmptyBasketWithUserId (long userId) {
            Basket newBasket = new Basket();
            newBasket.setUserId(userId);
            Set<Book> emptyBookSet = new HashSet<>();
            newBasket.setBookSet(emptyBookSet);
            basketRepository.save(newBasket);
    }

    public void removeBasketByUserId (long userId) {
        basketRepository.deleteByUserId(userId);
    }

    public Basket findBasketByUserId (long userId) {
        return basketRepository.findByUserId(userId);
    }

    public Basket getBasketByUserId (long userId) {
        return basketRepository.getByUserId(userId);
    }

    public void addBookToBasketByUserId (Book book, long userId) {
        if (!isBasketExistByUserId(userId)) {
            createNewEmptyBasketWithUserId(userId);
        }
        basketRepository.getByUserId(userId).getBookSet().add(book);
    }

    public boolean isBasketExistByUserId (long userId) {
        return basketRepository.existsByUserId(userId);
    }



}