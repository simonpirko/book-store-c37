package by.tms.bookstorec37.controller;

import by.tms.bookstorec37.entity.Basket;
import by.tms.bookstorec37.entity.Book;
import by.tms.bookstorec37.entity.Order;
import by.tms.bookstorec37.entity.OrderStatus;
import by.tms.bookstorec37.service.BasketService;
import by.tms.bookstorec37.service.OrderService;
import by.tms.bookstorec37.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.Date;
import java.util.List;
import java.util.Set;

@Controller
@RequestMapping(path = {"/order", "/"})
public class BasketContoller {

    @Autowired
    BasketService basketService;

    @Autowired
    OrderService orderService;

    @Autowired
    UserService userService;

    @GetMapping(path = "/basket")
    public ModelAndView showBasket (@ModelAttribute("ModelAttribute") Basket basket, List<Book> bookList,
                                    ModelAndView modelAndView) {
        modelAndView.setViewName("/order/basket");
        basket.setBookList(bookList);
        modelAndView.addObject("basket", basket);
        return modelAndView;
    }

    @PostMapping(path = "/basket")
    public ModelAndView createNewOrder (@ModelAttribute("ModelAttribute") Basket basket,
                                       ModelAndView modelAndView) {
        modelAndView.setViewName("/order/newOrder");
        Order newOrder = new Order();
        newOrder.setBookList(basket.getBookList());
        newOrder.setOrderStatus(OrderStatus.NEW);
        newOrder.setUser(userService.getUserById(basket.getUserId()));
        newOrder.setOrderCreationDate(new Date().toString());
        modelAndView.addObject("newOrder", newOrder);
//        orderService.addNewOrder(newOrder);
        return modelAndView;
    }
}
