package by.tms.bookstorec37.controller;

import by.tms.bookstorec37.entity.Book;
import by.tms.bookstorec37.service.BasketService;
import by.tms.bookstorec37.service.BookServise;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/order")
public class BookShelfController {

    @Autowired
    private BookServise bookServise;
    @Autowired
    private BasketService basketService;

    @GetMapping(path = "/bookShelf")
    public ModelAndView showBookShelfPage (@ModelAttribute("ModelAttribute") List<Book> bookList,
                                           ModelAndView modelAndView) {
//        modelAndView.addObject("allBooksList", bookService.getAllBooks());
        List<Book> testBookList = new ArrayList<>();
        Book book1 = new Book("test1");
        Book book2 = new Book("test2");
        Book book3 = new Book("test3");
        testBookList.add(book1);
        testBookList.add(book2);
        testBookList.add(book3);
        modelAndView.setViewName("/order/bookShelf");
        modelAndView.addObject("testBookList", testBookList);
        return modelAndView;
    }

//    @ModelAttribute("ModelAttribute") List<Book> bookList,
    @PostMapping(path = "/bookShelf")
    public ModelAndView getBooksForBasket (@ModelAttribute("ModelAttribute") List<Book> bookList,
                                           ModelAndView modelAndView){
//        basketService.addBookList(bookList);
        modelAndView.setViewName("/order/basket");
        return modelAndView;
    }
}