package by.tms.bookstorec37;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookStoreC37Application {

	public static void main(String[] args) {
		SpringApplication.run(BookStoreC37Application.class, args);
	}

}
